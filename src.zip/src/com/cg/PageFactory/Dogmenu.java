package com.cg.PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Dogmenu {
	WebDriver driver;
	
	@FindBy(linkText =" K9-BD-01")
	WebElement dogbutton;
	
	 public  Dogmenu(WebDriver driver) {
		 this.driver = driver;
		 PageFactory.initElements(driver, this);
	 }
	 
	 public void selectdog () 
	 {
		dogbutton.click();
	 }

	

}
