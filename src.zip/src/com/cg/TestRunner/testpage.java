package com.cg.TestRunner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;

import com.cg.PageFactory.HomePage;

public class testpage {
	WebDriver driver;
	HomePage page;	
	@BeforeClass
	public void beforeClass() {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://demo.opencart.com/");
		page = new HomePage(driver);
	}
}
