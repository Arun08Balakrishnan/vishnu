package com.cg.TestRunner;


import java.io.IOException;
import java.util.Hashtable;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.cg.ExcelReader.ReadfromExcel;


public class TestRunner {
WebDriver driver;
	
	@BeforeMethod
	public void before() {
		
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://jpetstore.cfapps.io/catalog");
		driver.findElement(By.xpath("//*[@id=\"MenuContent\"]/a[2]")).click();
		
		
		
	}
	@Test(dataProvider="AcceptUserDetails")
	public void YourStore(Hashtable<String, String> tb) throws InterruptedException, NoSuchElementException{
		
		WebElement Username=driver.findElement(By.xpath("//*[@id=\"Catalog\"]/form/p[2]/input[1]"));
		Username.clear();
		Username.sendKeys(tb.get("Username"));
		WebElement Password=driver.findElement(By.xpath("//*[@id=\"Catalog\"]/form/p[2]/input[2]"));
		Password.clear();
		Password.sendKeys(tb.get("Password"));
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"login\"]")).click();
		
	/*	String ActualTitle = driver.findElement(By.xpath("//*[@id=\"WelcomeContent\"]/div")).getText();
		System.out.println(ActualTitle);
		String ExpectedTitle = "Welcome Durvesh";
		if(ActualTitle.equals(ExpectedTitle)) {
			System.out.println("Invalid Input with Warning: No match for Username and/or Password.");
		}
		else {
			System.out.println("valid Input");
		}*/
		
	}
	
	@DataProvider
	public Object[][] AcceptUserDetails() throws IOException, InvalidFormatException {
		
		String filename ="LoginDetails.xlsx";
		String filepath= System.getProperty("user.dir")+"/src/com/cg/Testdata";
		String sheetname = "Sheet1";
		return ReadfromExcel.ReadExcelData(filepath, filename, sheetname);
}
}