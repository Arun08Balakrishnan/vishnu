package com.cg.testrunner;

import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.cg.ExcelReader.ReadFromExcel;
import com.cg.pagefactory.PHPTravels;

public class PHPRunner {

	PHPTravels php;
	WebDriver driver;

	@BeforeMethod
	public void PHPHome() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\VnV\\Module 4\\Advanced Selenium Libs\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.phptravels.net/");
		php = new PHPTravels(driver);
	}

	@Test(priority = 3)
	public void title() {
		String actual = driver.getTitle();
		String expected = "PHPTRAVELS | Travel Technology Partner";
		Assert.assertEquals(actual, expected);
	}

	@Test(priority = 1, dataProvider = "SigninDetails")
	public void SignUp(Hashtable<String, String> tb)
			throws InterruptedException {
		php.myAccount.click();
		php.signUp.click();
		php.firstName.clear();
		php.firstName.sendKeys(tb.get("Firstname"));
		Thread.sleep(1000);
		php.lastName.clear();
		php.lastName.sendKeys(tb.get("Lastname"));
		Thread.sleep(1000);
		php.phone.clear();
		php.phone.sendKeys(tb.get("Mobile"));
		Thread.sleep(1000);

		php.email.clear();
		php.email.sendKeys(tb.get("Email"));
		Thread.sleep(1000);
		php.password.clear();
		php.password.sendKeys(tb.get("Password"));
		Thread.sleep(1000);
		php.cnfpassword.clear();
		php.cnfpassword.sendKeys(tb.get("Password"));
		Thread.sleep(1000);
		php.cook.click();
		// driver.switchTo().window("signBtn");
		php.signBtn.click();
		// driver.manage().getCookies();
		Thread.sleep(1000);

	}

	@Test(priority = 2, dataProvider = "LoginDetails")
	public void Login(Hashtable<String, String> tb) throws InterruptedException {
		php.myAccount.click();
		php.logIn.click();
		php.userName.sendKeys(tb.get("Username"));
		Thread.sleep(1000);
		php.logPassword.clear();
		php.logPassword.sendKeys("Password");
		php.cook.click();
		// driver.switchTo().window("logBtn");
		// driver.manage().getCookies();
		php.logBtn.click();

	}

	@Test(priority = 0)
	public void Carvalidation() {

		php.cars.click();

		Select s = new Select(php.carslo);
		s.selectByValue("11");
		php.cook.click();
		php.carsearch.click();

	}

	
	
	@DataProvider
	public Object[][] SigninDetails() throws IOException {

		String filename = "PHPTravelsSign.xlsx";
		String filepath = "C:/Java_Workspace/Copy of Selenium/src/com/cg/testdata";
		String sheetname = "Sheet1";
		return ReadFromExcel.ReadExcelData(filepath, filename, sheetname);
	}

	@DataProvider
	public Object[][] LoginDetails() throws IOException {

		String filename = "PHPTravelsLog.xlsx";
		String filepath = "C:/Java_Workspace/Copy of Selenium/src/com/cg/testdata";
		String sheetname = "Sheet1";
		return ReadFromExcel.ReadExcelData(filepath, filename, sheetname);

	}

}
