package com.cg.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
    
public class PHPTravels {
	WebDriver driver;
	@FindBy(css=".nav:nth-child(1) > #li_myaccount > .dropdown-toggle")
	public WebElement myAccount;
	
	@FindBy(linkText="Sign Up")
	public WebElement signUp;
	
	@FindBy(css=".nav:nth-child(1) > #li_myaccount li:nth-child(1) > .go-text-right")
	public WebElement logIn;
	
	@FindBy(name="firstname")
	public WebElement firstName;
	
	@FindBy(name="lastname")
	public WebElement lastName;
	
	@FindBy(name="phone")
	public WebElement phone;
	
	@FindBy(name="email")
	public WebElement email;
	
	@FindBy(name="password")
	public WebElement password;
	
	@FindBy(name="confirmpassword")
	public WebElement cnfpassword;
	
	@FindBy(css=".signupbtn") 
	public WebElement signBtn;
	
	@FindBy(name="username")
	public WebElement userName;
	
	@FindBy(id="cookyGotItBtn")
	public WebElement cook;
	
	
	@FindBy(name="password") 
	public WebElement logPassword;
	
	
	@FindBy(css=".btn-action") 
	public WebElement logBtn;
	
	
	
	
	@FindBy(css=".text-center:nth-child(4) > .text-center")
	public WebElement cars;
	
	@FindBy(xpath = "//*[@id='s2id_carlocations']/a/span[1]")
	public WebElement carText;
	@FindBy(id="carlocations")
	public WebElement carslo;
	@FindBy(css=".select2-chosen")
	public WebElement carslocation;
	
	@FindBy(css=".bgfade > .loader")
	public WebElement carsearch;
	
	

	
	public PHPTravels(WebDriver driver1) {
		
		this.driver=driver1;
		PageFactory.initElements(driver1, this);
	}}
	