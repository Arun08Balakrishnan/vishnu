package com.cg.ExcelReader;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Hashtable;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadFromExcel {
	
	public static Object[][] ReadExcelData(String filepath,String filename, String sheetname) throws IOException{
		File file= new File(filepath + "/" + filename);
		FileInputStream in = new FileInputStream(file);
		XSSFWorkbook workbook = new XSSFWorkbook(in);
		Sheet sheet = workbook.getSheet(sheetname);
		int rowcount = sheet.getLastRowNum();  //3 data row + 1 colrow =3
		//2dimensional object array declaration
		Object[][] data = new Object[rowcount][1];
		//all the keys are available in first row - header row
		Row keyrow= sheet.getRow(0);
		Hashtable<String, String> rec=null;
		for (int r=1;r<rowcount+1;r++)
		{
			Row datarow = sheet.getRow(r);  //get the current row
			rec = new Hashtable<String, String>();
			for ( int c=0;c<datarow.getLastCellNum();c++)
			{	
				String key= keyrow.getCell(c).getStringCellValue();
				String val= datarow.getCell(c).getStringCellValue();
				rec.put(key, val);
				System.out.println(key+":"+val);
			}
			data[r-1][0]=rec;
		}
		return data;
	}
	

}