package com.cg.testrunner;

import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;




import com.cg.ExcelReader.ReadFromExcel;
import com.cg.pagefactory.PHPTravels;

public class PHPRunner {
	
	PHPTravels php;
	WebDriver driver;
	
	@BeforeMethod
	public void PHPHome(){
		System.setProperty("webdriver.chrome.driver", "D:\\VnV\\Module 4\\Advanced Selenium Libs\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.phptravels.net/");
	}
	
    @Test(priority=0,dataProvider="SigninDetails")
    
    	public void SignUp(Hashtable<String, String> tb) throws InterruptedException{
        php.myAccount.click();
        php.signUp.click();
        php.firstName.clear();
        php.firstName.sendKeys(tb.get("Firstname"));
        php.lastName.clear();
        php.lastName.sendKeys(tb.get("Lastname"));
        php.phone.clear();
        php.phone.sendKeys(tb.get("Mobile"));
        
        php.email.clear();		
		php.email.sendKeys(tb.get("Email"));
        php.password.clear();
        php.password.sendKeys(tb.get("Password"));
        php.cnfpassword.clear();
        php.cnfpassword.sendKeys(tb.get("conpassword"));
        php.signBtn.click();
    	
    }
    
    
   @Test(priority=1)
   public void Login(Hashtable<String, String> tb) throws InterruptedException{
	   
	   
	   
   }
	
   @DataProvider
	public Object[][] SigninDetails() throws IOException {
		
		String filename ="PHPTravelsSign.xlsx";
		String filepath= System.getProperty("user.dir")+"src/com/cg/testdata";
		String sheetname = "Sheet1";
		return ReadFromExcel.ReadExcelData(filepath, filename, sheetname);
   }
		public Object[][] LoginDetails() throws IOException {
			
			String filename ="PHPTravelsLog.xlsx";
			String filepath= System.getProperty("user.dir")+"src/com/cg/testdata";
			String sheetname = "Sheet1";
			return ReadFromExcel.ReadExcelData(filepath, filename, sheetname);
	   
	}
   
    
   
}

