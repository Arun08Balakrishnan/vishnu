package com.cg.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
    
public class PHPTravels {
	WebDriver driver;
	@FindBy(xpath="//*[@id='li_myaccount']/a")
	public WebElement myAccount;
	
	@FindBy(xpath="//*[@id='li_myaccount']/ul/li[2]/a")
	public WebElement signUp;
	
	@FindBy(xpath="//*[@id='li_myaccount']/ul/li[1]/a")
	public WebElement logIn;
	
	@FindBy(name="firstname")
	public WebElement firstName;
	
	@FindBy(name="lastname")
	public WebElement lastName;
	
	@FindBy(name="phone")
	public WebElement phone;
	
	@FindBy(name="email")
	public WebElement email;
	
	@FindBy(name="password")
	public WebElement password;
	
	@FindBy(name="confirmpassword")
	public WebElement cnfpassword;
	
	@FindBy(xpath="//*[@id='headersignupform']/div[9]/button") 
	public WebElement signBtn;
	
	@FindBy(name="username")
	public WebElement userName;
	
	
	@FindBy(xpath="//*[@id='loginfrm']/div[1]/div[5]/div/div[2]/input") 
	public WebElement logPassword;
	
	
	@FindBy(xpath="//*[@id='loginfrm']/button") 
	public WebElement logBtn;
	
	public PHPTravels(WebDriver driver1) {
		this.driver=driver1;
	}}
	/*public void VerifyTitle() {
		String title=driver.getTitle();
		String Title = "Your Store";
		if (title.equals(Title)) {
			System.out.println("True");
		} else {
			System.out.println("false");
		}
	}
	public void SeDeskButton() {
		desktopButton.click();
	}
	public void SelMac() {
		Mac1.click();
		
	}
	public void VerifyMacHead() {
		 String Title = "Mac";
		if (Mac1Heading.getText().equals(Title)) {
			System.out.println("True");
		} else {
			System.out.println("false");
		}
	}
	public void sortandSelect(String drop) {
		//driver.findElement(sortBy).click();
		Select sel = new Select(sortBy);
		 sel.selectByVisibleText(drop);
		//driver.findElement(selectby).click();
	}
	public void addingtoCart() {
		addcart.click();
	}
	public void SelectSearchAndSend(String name) {
		searchLoc.sendKeys(name);
		search.click();
		}
	public void selectSearc1() {
		search1.clear();
	}
	public void SelDescAndSelectsearch() {
		selectDesc.click();
		SearchN.click();
	}
	public void SelectsearcandsendKeys(String name2) {
		Selsearch.clear();
		Selsearch.sendKeys(name2);
		Clicksearch.click();
	}
	
	

}
*/