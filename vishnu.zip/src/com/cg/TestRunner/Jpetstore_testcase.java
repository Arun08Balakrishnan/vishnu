package com.cg.TestRunner;

import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.cg.ExcelReader.ReaderFromExcel;
import com.cg.PageFactory.Jpetstore_Pagefactory;

public class Jpetstore_testcase {
	Jpetstore_Pagefactory jpet;
	WebDriver driver;

	@BeforeMethod
	public void jpetstore() {
		System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://jpetstore.cfapps.io/catalog");
		driver.findElement(By.xpath("//*[@id=\"MenuContent\"]/a[2]")).click();
		jpet = new Jpetstore_Pagefactory(driver);
	}

	@Test(priority = 1)
	public void Title() {
		String actual = driver.getTitle();
		String expected = "JPetStore Demo";
		Assert.assertEquals(actual, expected);
	}

	@Test(priority = 2, dataProvider = "SigninDetails")
	public void SignUp(Hashtable<String, String> tb) throws InterruptedException, NoSuchElementException {
		
		jpet.username.click();
		jpet.username.sendKeys(tb.get("Username"));
		Thread.sleep(1000);
		jpet.password.click();
		jpet.password.sendKeys(tb.get("Password"));
		Thread.sleep(1000);
		
		
		jpet.login.click();
		Thread.sleep(1000);

	}
	
	@Test(priority = 3, dataProvider = "correcrdetails")
	public void imagemenuvalidator(Hashtable<String, String> mc) throws InterruptedException, NoSuchElementException {
		
		jpet.username.click();
		jpet.username.sendKeys(mc.get("Username"));
		Thread.sleep(1000);
		jpet.password.click();
		jpet.password.sendKeys(mc.get("Password"));
		Thread.sleep(1000);
		jpet.login.click();
		Thread.sleep(1000);
		jpet.doglink.click();
		String title=driver.findElement(By.xpath("//*[@id=\"Catalog\"]/table/tbody/tr[2]/td[2]")).getText();
		String Title = "Bulldog";
		if (title.equals(Title)) {
			System.out.println("image menu button validated");
		} else {
			System.out.println("image menu button not working");
		}

	}
	@Test(priority = 4, dataProvider = "correcrdetails")
	public void logout(Hashtable<String, String> tb) throws InterruptedException, NoSuchElementException {
		
		jpet.username.click();
		jpet.username.sendKeys(tb.get("Username"));
		Thread.sleep(1000);
		jpet.password.click();
		jpet.password.sendKeys(tb.get("Password"));
		Thread.sleep(1000);
		jpet.login.click();
		Thread.sleep(1000);
		jpet.signout.click();

	}

/*	@Test(priority = 2, dataProvider = "LoginDetails")
	public void Login(Hashtable<String, String> tb) throws InterruptedException {
		jpet.myAccount.click();
		jpet.logIn.click();
		jpet.userName.sendKeys(tb.get("Username"));
		Thread.sleep(1000);
		jpet.logPassword.clear();
		jpet.logPassword.sendKeys("Password");
		jpet.cook.click();
		// driver.switchTo().window("logBtn");
		// driver.manage().getCookies();
		jpet.logBtn.click();

	}

	@Test(priority = 0)
	public void Carvalidation() {

		jpet.cars.click();

		Select s = new Select(jpet.carslo);
		s.selectByValue("11");
		jpet.cook.click();
		jpet.carsearch.click();

	}
*/
	@DataProvider
	public Object[][] SigninDetails() throws IOException {

		String filename = "LoginDetails.xlsx";
		String filepath = "C:\\java_workspace\\Mini_Project2\\src\\com\\cg\\Testdata";
		String sheetname = "Sheet1";
		return ReaderFromExcel.ReadExcelData(filepath, filename, sheetname);
	}
	
	@DataProvider
	public Object[][] correcrdetails() throws IOException {

		String filename = "correctdetails.xlsx";
		String filepath = "C:\\java_workspace\\Mini_Project2\\src\\com\\cg\\Testdata";
		String sheetname = "Sheet1";
		return ReaderFromExcel.ReadExcelData(filepath, filename, sheetname);
	}

	
}
