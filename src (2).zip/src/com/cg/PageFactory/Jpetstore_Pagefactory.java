package com.cg.PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Jpetstore_Pagefactory {
	WebDriver driver;

	@FindBy(xpath = "//*[@id=\"MenuContent\"]/a[2]]")
	public WebElement signin;

	
	@FindBy(name = "username")
	public WebElement username;

	@FindBy(name = "password")
	public WebElement password;

	@FindBy(id = "login")
	public WebElement login;

	@FindBy(xpath = "//*[@id=\"Catalog\"]/a")
	public WebElement Register;

	

	@FindBy(name = "confirmpassword")
	public WebElement cnfpassword;

	@FindBy(css = ".signupbtn")
	public WebElement signBtn;

	@FindBy(name = "username")
	public WebElement userName;

	@FindBy(id = "cookyGotItBtn")
	public WebElement cook;

	@FindBy(name = "password")
	public WebElement logPassword;

	@FindBy(css = ".btn-action")
	public WebElement logBtn;
	
	
	@FindBy(xpath = "//*[@id=\"MainImageContent\"]/map/area[3]")
	public WebElement doglink;


	@FindBy(css = ".text-center:nth-child(4) > .text-center")
	public WebElement cars;

	@FindBy(xpath = "//*[@id=\"MenuContent\"]/a[2]")
	public WebElement signout;
	
	@FindBy(id = "carlocations")
	public WebElement carslo;
	
	@FindBy(css = ".nav:nth-child(1) > #li_myaccount > .dropdown-toggle")
	public WebElement myAccount;
	

	@FindBy(linkText = "Sign Up")
	public WebElement signUp;

	@FindBy(css = ".nav:nth-child(1) > #li_myaccount li:nth-child(1) > .go-text-right")
	public WebElement logIn;
	
	@FindBy(css = ".select2-chosen")
	public WebElement carslocation;

	@FindBy(css = ".bgfade > .loader")
	public WebElement carsearch;

	public Jpetstore_Pagefactory(WebDriver driver1) {

		this.driver = driver1;
		PageFactory.initElements(driver1, this);
	}
}
