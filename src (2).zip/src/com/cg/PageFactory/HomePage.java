package com.cg.PageFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
 WebDriver driver;
 
 @FindBy(xpath="//*[@id=\"MenuContent\"]/a[2]")
 private WebElement signin;
 
 @FindBy(xpath="//*[@id=\"MainImageContent\"]/map/area[3]")
 private WebElement doglink;
 
    By uname =By.name("username");
	
    By pwd =By.name("password");
	
	//@FindBy(name="password")
	//private WebElement pwd;
	
	@FindBy(id="login")
	private WebElement loginbutton;
 
 public  HomePage(WebDriver driver) {
	 this.driver = driver;
	 PageFactory.initElements(driver, this);
 }
 


  public void VerifyTitle() {
		String title=driver.getTitle();
		String Title = "JPetStore Demo";
		if (title.equals(Title)) {
			System.out.println("title verified");
		} else {
			System.out.println("title not verified");
		}
	}
  public void signin()
  {
 	 signin.click();
  }
	
	public void enteruser(String name) {
		driver.findElement( uname).sendKeys(name);
	}
	public void enterpass(String name) {
		driver.findElement( pwd).sendKeys(name);
	}

	public void loginbutton() {
		loginbutton.click();
		
	}

	public void dogmenu() {
		doglink.click();
		String title=driver.findElement(By.xpath("//*[@id=\"Catalog\"]/table/tbody/tr[2]/td[2]")).getText();
		String Title = "Bulldog";
		if (title.equals(Title)) {
			System.out.println("image menu button validated");
		} else {
			System.out.println("image menu button not working");
		}
		
	}
	
	}
