package com.cg.PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SigninPage {
	WebDriver driver;
	
	@FindBy(name="username")
	private WebElement uname;
	
	@FindBy(name="password")
	private WebElement pwd;
	
	@FindBy(name="login")
	private WebElement loginbutton;

	 public  SigninPage(WebDriver driver) {
		 this.driver = driver;
		 PageFactory.initElements(driver, this);
	 }
	 
	 public void signin(String name,String password) {
		 uname.sendKeys(name);
		 pwd.sendKeys(password);
		 loginbutton.click();
	 }
}
