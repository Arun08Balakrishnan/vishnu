package com.cg.TestRunner;



import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import com.cg.PageFactory.HomePage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class Testcase11_1 {
	WebDriver driver;
	HomePage page;	
	@BeforeClass
	public void beforeClass() {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://jpetstore.cfapps.io/catalog");
		page = new HomePage(driver);
	}

	@Test
	public void Testcases() {
		page.VerifyTitle();
	
	}
	
	@Test
	public void testCase() {
		page.signin();
		page.enteruser("durveshkoli");
		page.enterpass("12345678");
		page.loginbutton();
		page.dogmenu();
		/*page.VerifyMacHead();
		page.sortandSelect("Name (A - Z)");
		page.addingtoCart();
		page.SelectSearchAndSend("Mobile");
		page.selectSearc1();
		page.SelDescAndSelectsearch();
		page.SelectsearcandsendKeys("Monitors");*/
	}
	

}
